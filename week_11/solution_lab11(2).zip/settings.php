<?php

// Include file with sql details
	$host = "mysql.ict.swin.edu.au";
	$user = "s1234567";
	$pwd  = "ddmmyy";
	$sql_db  = "s1234567_db";

?>