"Read Me" for Lab11 Solution Files:

Note that 'member_add.php', 'member_display.php', 'member_search.php' ALREADY incorporates Extension Task 1 solution with;
 require_once('settings.php');

You will need to change 'settings.php' to your connection details.

